var get_ranking_pics = function() {
//  var rankingUrl = 'http://coneco.cat2.pics/api/v1/cats/';
//  var deferred = $.ajax({
//    url     : rankingUrl,
//    type    : 'GET',
//    dataType: 'jsonp',
//  });
//  return deferred.promise();
};

var set_ranking_pics = function() {
//  get_ranking_pics()
//    .then(function(pics) {
//      $.each(pics, function(index, pic) {
//        var item = String();
//        var form = String();
//        form += "<form action='/api/v1/favorites/' method='post'>";
//        form += "<input type='hidden' name='cat_id' value='" + pic.id + "'>";
//        form += "<button type='submit' class='btn btn-lg btn-primary'>";
//        form += "ふぁぼる";
//        form += "</button>";
//        form += "</form>";
//        if (index == 0) {
//          item += "<div class='container'>";
//            item += "<div class='row'>";
//              item += "<div class='col-lg-6 col-lg-offset-3 col-md-6 col-md-offset-3'>";
//                item += "<div class='text-center'>";
//                  item += "<p class='text-ranking'><B>ふぁぼランキング1位</B></p>";
//                  item += "<img src='" + pic.image_url + "' class='img-responsive img-round' alt='img'></a>";
//                  item += form;
//                item += "</div>";
//              item += "</div>";
//            item += "</div>";
//          item += "</div>";
//          $('#ranking').append(item);
//        }
//        if (index == 0) {
//          return false;
//        }
//      })
//    })
};
